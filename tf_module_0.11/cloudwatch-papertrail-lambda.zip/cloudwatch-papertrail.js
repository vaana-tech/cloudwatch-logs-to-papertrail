"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const zlib = require("zlib");
const winston = require("winston");
require("winston-papertrail");
function unarchiveLogData(payload) {
    return new Promise((resolve, reject) => {
        zlib.gunzip(payload, function (err, result) {
            if (err) {
                return reject(err);
            }
            else {
                return resolve(result);
            }
        });
    }).then(rawData => {
        return JSON.parse(rawData.toString('utf8'));
    });
}
function getEnvVarOrFail(varName) {
    const value = process.env[varName];
    if (!value) {
        throw new Error(`Required environment variable ${varName} is undefined`);
    }
    return value;
}
function getEnvVarOrDefault(varName, defValue) {
    const value = process.env[varName];
    if (!value) {
        return defValue;
    }
    return value;
}
// Should match winston simple log format for example: "error: The database has exploded"
// For more information see https://github.com/winstonjs/winston
// The pattern represents the following:
// A sequence of non-tab chars at the start of input followed by a tab
// Another sequence of non-tabs followed by a tab
// Capture a group of alphanumeric chars leading up to a ':'
const logLevelRegex = /^[^\t]+\t[^\t]+\t(\w+):/;
// default Rails Sematic Logger format
// <space><firs letter of level><space>
const logLevelRegexRails = /\s([DIWEF])\s\[/;
function parseLogLevel(tsvMessage) {
    // Messages logged manually are tab separated value strings of three columns:
    // date string (ISO8601), request ID, log message
    const match = logLevelRegex.exec(tsvMessage);
    return match && match[1].toLowerCase();
}
exports.parseLogLevel = parseLogLevel;
function parseLogLevelRails(tsvMessage) {
    // Messages logged manually are tab separated value strings of three columns:
    // date string (ISO8601), request ID, log message
    const match = logLevelRegexRails.exec(tsvMessage);
    // see https://github.com/winstonjs/winston#logging-levels
    const mapping = { "D": 'debug', 'I': 'info', 'W': 'warn', 'E': 'error', 'F': 'crit' };
    if (match) {
        return mapping[match[1].toString()];
    }
    return null;
}
exports.parseLogLevelRails = parseLogLevelRails;
function parseTypedLogLevel(type, tsvMessage) {
    if (type == 'RAILS') {
        return parseLogLevelRails(tsvMessage);
    }
    return parseLogLevel(tsvMessage);
}
exports.handler = (event, context, callback) => {
    const host = getEnvVarOrFail('PAPERTRAIL_HOST');
    const port = getEnvVarOrFail('PAPERTRAIL_PORT');
    const shouldParseLogLevels = getEnvVarOrFail('PARSE_LOG_LEVELS') === "true";
    const logLevelFormat = getEnvVarOrDefault('LOG_FORMAT', 'WINSTON');
    const payload = new Buffer(event.awslogs.data, 'base64');
    unarchiveLogData(payload)
        .then((logData) => {
        console.log("Got log data");
        console.log(logData);
        const papertrailTransport = new winston.transports.Papertrail({
            host,
            port,
            program: logData.logStream,
            hostname: logData.logGroup,
            flushOnClose: true,
            colorize: true,
        });
        const logger = new (winston.Logger)(Object.assign({}, (logLevelFormat === 'RAILS' ? { levels: {
                debug: 7,
                info: 6,
                notice: 5,
                warning: 4,
                warn: 4,
                error: 3,
                err: 3,
                crit: 2,
                alert: 1,
                emerg: 0,
            }, } : {}), { transports: [papertrailTransport] }));
        logData.logEvents.forEach(function (event) {
            const logLevel = shouldParseLogLevels
                ? parseTypedLogLevel(logLevelFormat, event.message) || 'info'
                : 'info';
            logger.log(logLevel, event.message);
        });
        logger.close();
        return callback(null);
    })
        .catch(callback);
};
